from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:

    def __init__(
        self,
        username=None,
        password=None,
        host="localhost",
        port=27017,
        database="aac",
        collection="animals",
    ):
        if not username or not password:
            raise ValueError("Username and password are required.")

        self.client = MongoClient(
            f"mongodb://{username}:{password}@{host}:{port}/{database}?authSource=admin",
            serverSelectionTimeoutMS=5000,
        )
        self.database = self.client[database]
        self.collection = self.database[collection]

    def create(self, data):
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dictionary.")
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as exc:
            print(f"Create error: {exc}")
            return False

    def read(self, query):
        if not isinstance(query, dict):
            raise ValueError("query must be a dictionary.")
        try:
            return list(self.collection.find(query))
        except PyMongoError as exc:
            print(f"Read error: {exc}")
            return []

    def update(self, query, new_values):
        if not isinstance(query, dict) or not isinstance(new_values, dict) or not new_values:
            raise ValueError("query and non-empty new_values dictionaries are required.")
        try:
            result = self.collection.update_many(query, new_values)
            return result.modified_count
        except PyMongoError as exc:
            print(f"Update error: {exc}")
            return 0

    def delete(self, query):
        if not isinstance(query, dict):
            raise ValueError("query must be a dictionary.")
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as exc:
            print(f"Delete error: {exc}")
            return 0

    def close(self):
        self.client.close()
